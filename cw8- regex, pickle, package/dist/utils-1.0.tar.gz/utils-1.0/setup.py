from setuptools import setup

setup(
   name='utils',
   version='1.0',
   description='A useful module',
   author='Man Foo',
   author_email='foomail@foo.example',
   packages=['utils'],  #same as name
   install_requires=[], #external packages as dependencies
)